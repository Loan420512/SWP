package com.evswap.entity;

public enum Role { Driver, Staff, Admin }  // khớp cột Role trong DB
