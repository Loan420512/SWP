package com.evswap.service;
public record StationStatusSummary(String status, long quantity) {}
