package com.evswap.repository;
import com.evswap.entity.Battery;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BatteryRepository extends JpaRepository<Battery, Integer> {}
